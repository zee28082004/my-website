import api from "@/lib/api";
import { useMutation } from "@tanstack/react-query";
import { AxiosError } from "axios";

export type ContactPayload = {
	name: string;
	email: string;
	message: string;
};

const sendContactMessage = async (payload: ContactPayload) => {
	const { data } = await api.post("admin/email/send-email", payload);
	return data;
};

export const useSendContact = (options?: {
	onSuccess?: () => void;
	onError?: (error: AxiosError) => void;
}) =>
	useMutation({
		mutationFn: sendContactMessage,
		retry: (failureCount, error) => {
			const status = (error as AxiosError)?.response?.status;
			if (status === 429) return false;
			return failureCount < 1;
		},
		onSuccess: options?.onSuccess,
		onError: (error) => options?.onError?.(error as AxiosError),
	});
