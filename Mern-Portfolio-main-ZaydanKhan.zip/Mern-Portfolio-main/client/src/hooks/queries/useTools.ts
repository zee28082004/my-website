import api from "@/lib/api";
import { queryKeys } from "@/lib/queryKeys";
import { useQuery } from "@tanstack/react-query";

const fetchTools = async (): Promise<ITool[]> => {
	const { data } = await api.get<{ tools: ITool[] }>("admin/tool/get-tools");
	return data.tools;
};

export const useTools = () =>
	useQuery({
		queryKey: queryKeys.tools,
		queryFn: fetchTools,
	});
