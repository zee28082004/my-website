import api from "@/lib/api";
import { queryKeys } from "@/lib/queryKeys";
import { useQuery } from "@tanstack/react-query";

const fetchProjects = async (): Promise<IProject[]> => {
	const { data } = await api.get<{ projects: IProject[] }>(
		"admin/project/get-projects",
	);
	return data.projects;
};

export const useProjects = () =>
	useQuery({
		queryKey: queryKeys.projects,
		queryFn: fetchProjects,
	});
