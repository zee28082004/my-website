const RouteFallback = () => (
	<div
		className="flex min-h-svh w-full items-center justify-center bg-black"
		aria-busy="true"
		aria-live="polite"
	>
		<div className="size-2 animate-pulse rounded-full bg-white/40" />
	</div>
);

export default RouteFallback;
