import { Component, ErrorInfo, ReactNode } from "react";

type Props = {
	children: ReactNode;
	fallback?: ReactNode;
};

type State = {
	hasError: boolean;
};

class ErrorBoundary extends Component<Props, State> {
	state: State = { hasError: false };

	static getDerivedStateFromError(): State {
		return { hasError: true };
	}

	componentDidCatch(error: Error, info: ErrorInfo) {
		if (import.meta.env.DEV) {
			console.error("[ErrorBoundary]", error, info.componentStack);
		}
	}

	private handleReload = () => {
		this.setState({ hasError: false });
		window.location.reload();
	};

	render() {
		if (!this.state.hasError) return this.props.children;
		if (this.props.fallback) return this.props.fallback;

		return (
			<div className="flex min-h-svh w-full flex-col items-center justify-center gap-4 bg-black px-6 text-white">
				<p className="text-[10px] font-bold tracking-[0.4em] text-white/40 uppercase">
					[ SYSTEM_ERROR ]
				</p>
				<h1 className="text-2xl font-bold tracking-tighter md:text-3xl">
					Something broke.
				</h1>
				<p className="max-w-md text-center text-sm font-light text-white/50">
					An unexpected error interrupted the page. Reloading usually clears
					it.
				</p>
				<button
					type="button"
					onClick={this.handleReload}
					className="mt-2 border border-white/20 px-6 py-3 text-[10px] font-bold tracking-[0.3em] text-white/80 uppercase transition-colors hover:border-white/60 hover:text-white"
				>
					Reload
				</button>
			</div>
		);
	}
}

export default ErrorBoundary;
