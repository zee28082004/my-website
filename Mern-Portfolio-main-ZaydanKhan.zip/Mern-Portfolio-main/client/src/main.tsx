import { QueryClientProvider } from "@tanstack/react-query";
import { Analytics } from "@vercel/analytics/react";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./App";
import ErrorBoundary from "./components/common/ErrorBoundary";
import RefContextProvider from "./context/RefContextProvider";
import { queryClient } from "./lib/queryClient";
import "./index.css";

createRoot(document.getElementById("root")!).render(
	<StrictMode>
		<ErrorBoundary>
			<QueryClientProvider client={queryClient}>
				<RefContextProvider>
					<BrowserRouter>
						<App />
						<Analytics />
					</BrowserRouter>
				</RefContextProvider>
			</QueryClientProvider>
		</ErrorBoundary>
	</StrictMode>,
);
