import Hero from "@/components/hero/Hero";
import Navbar from "@/components/navbar/Navbar";
import { ReactLenis } from "lenis/react";
import { lazy, Suspense } from "react";

// Defer below-the-fold sections so the hero paints fast.
const Tools = lazy(() => import("@/components/tools/Tools"));
const Projects = lazy(() => import("@/components/projects/Project"));
const Contributions = lazy(() => import("@/components/github/Contributions"));
const Activity = lazy(() => import("@/components/activity/Activity"));
const Contact = lazy(() => import("@/components/contact/Contact"));
const Footer = lazy(() => import("@/components/footer/Footer"));

const SectionFallback = () => (
	<div className="h-96 w-full border-t border-white/5" aria-hidden="true" />
);

const Home = () => {
	return (
		<ReactLenis
			root
			options={{
				lerp: 0.05,
				duration: 1.5,
				wheelMultiplier: 1,
				touchMultiplier: 1.2,
				smoothWheel: true,
			}}
		>
			<Navbar />
			<div className="relative mx-auto h-full w-full overflow-x-hidden bg-black text-white selection:bg-white/20">
				<div className="pointer-events-none absolute inset-x-0 inset-y-0 z-0 mx-auto hidden max-w-7xl border-x border-white/10 xl:block" />

				<div className="flex h-svh max-h-svh min-h-svh w-full items-center justify-center">
					<Hero />
				</div>

				<Suspense fallback={<SectionFallback />}>
					<Tools />
					<Projects />
					<Contributions />
					<Activity />
					<Contact />
					<Footer />
				</Suspense>
			</div>
		</ReactLenis>
	);
};

export default Home;
