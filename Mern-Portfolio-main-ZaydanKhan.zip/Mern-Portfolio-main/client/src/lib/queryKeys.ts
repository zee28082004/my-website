export const queryKeys = {
	projects: ["projects"] as const,
	tools: ["tools"] as const,
} as const;
