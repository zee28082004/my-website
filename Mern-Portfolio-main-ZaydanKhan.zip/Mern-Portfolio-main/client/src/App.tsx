import { lazy, Suspense } from "react";
import { isBrowser } from "react-device-detect";
import { Route, Routes } from "react-router";
import RouteFallback from "./components/common/RouteFallback";

const Home = lazy(() => import("./pages/Home"));
const NotFound = lazy(() => import("./pages/NotFound"));

// Game is desktop-only; lazy + isBrowser keeps it out of the mobile bundle path.
const GamingHUDCursor = lazy(
	() => import("./components/game/GamingHUDCursor"),
);
const GhostHunter = lazy(() => import("./components/game/GhostHunter"));

const App = () => {
	return (
		<>
			{isBrowser && (
				<Suspense fallback={null}>
					<GamingHUDCursor />
					<GhostHunter />
				</Suspense>
			)}
			<div id="site-main">
				<Suspense fallback={<RouteFallback />}>
					<Routes>
						<Route path="/" element={<Home />} />
						<Route path="*" element={<NotFound />} />
					</Routes>
				</Suspense>
			</div>
		</>
	);
};

export default App;
