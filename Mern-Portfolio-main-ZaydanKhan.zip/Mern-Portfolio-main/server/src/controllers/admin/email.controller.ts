import { RequestHandler } from "express";
import transport from "../../helpers/nodeMailer";
import { AppError } from "../../utils/AppError";
import asyncHandler from "../../utils/asyncHandler";
import env from "../../utils/env";

const escapeHtml = (input: string) =>
	input
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/"/g, "&quot;")
		.replace(/'/g, "&#039;");

const sendEmail: RequestHandler = asyncHandler(async (req, res) => {
	const { name, email, message } = req.body as {
		name: string;
		email: string;
		message: string;
	};

	const safeMessage = escapeHtml(message).replace(/\n/g, "<br>");

	const info = await transport.sendMail({
		from: `"${escapeHtml(name)}" <${env.GMAIL_USER}>`,
		replyTo: `"${escapeHtml(name)}" <${email}>`,
		to: env.GMAIL_ID,
		subject: "New message from Portfolio",
		html: `
			<div style="font-family: Arial, sans-serif; padding: 10px;">
				<p><strong>Name:</strong> ${escapeHtml(name)}</p>
				<p><strong>Email:</strong> ${escapeHtml(email)}</p>
				<p><strong>Message:</strong><br>${safeMessage}</p>
			</div>
		`,
	});

	if (!info.accepted.length) {
		throw new AppError("Failed to send email", 502);
	}

	res.status(200).json({ success: true, message: "Email Sent" });
});

export { sendEmail };
