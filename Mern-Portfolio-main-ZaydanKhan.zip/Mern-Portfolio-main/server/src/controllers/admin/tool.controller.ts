import { RequestHandler } from "express";
import { ImageDeleteUtil } from "../../helpers/cloudinary";
import { invalidateCache } from "../../middlewares/cache.middleware";
import Tool from "../../models/tools";
import { AppError } from "../../utils/AppError";
import asyncHandler from "../../utils/asyncHandler";

const CACHE_TAG = "tools";

const getTools: RequestHandler = asyncHandler(async (_req, res) => {
	const tools = await Tool.find()
		.sort({ order: 1, createdAt: -1 })
		.select("-image.public_id -__v")
		.lean();

	res.status(200).json({
		success: true,
		message: "Tools fetched",
		tools,
	});
});

const addTool: RequestHandler = asyncHandler(async (req, res) => {
	await Tool.create(req.body);
	invalidateCache(CACHE_TAG);
	res.status(201).json({ success: true, message: "Tool added" });
});

const updateTool: RequestHandler = asyncHandler(async (req, res) => {
	const { id } = req.params;
	const data = req.body;

	const tool = await Tool.findById(id);
	if (!tool) throw new AppError("Tool not found", 404);

	if (data.image?.url && tool.image?.public_id) {
		await ImageDeleteUtil(tool.image.public_id);
	}

	tool.name = data.name ?? tool.name;
	tool.image = data.image?.url ? data.image : tool.image;

	await tool.save();
	invalidateCache(CACHE_TAG);

	res.status(200).json({
		success: true,
		message: "Tool updated successfully",
	});
});

const deleteTool: RequestHandler = asyncHandler(async (req, res) => {
	const { id } = req.params;

	const tool = await Tool.findById(id);
	if (!tool) throw new AppError("Tool not found", 404);

	if (tool.image?.public_id) {
		await ImageDeleteUtil(tool.image.public_id);
	}
	await Tool.deleteOne({ _id: id });
	invalidateCache(CACHE_TAG);

	res.status(200).json({ success: true, message: "Tool deleted" });
});

const reorderTools: RequestHandler = asyncHandler(async (req, res) => {
	const { tools } = req.body;

	const operations = tools.map((id: string, index: number) => ({
		updateOne: {
			filter: { _id: id },
			update: { $set: { order: index } },
		},
	}));

	if (operations.length) await Tool.bulkWrite(operations);
	invalidateCache(CACHE_TAG);

	res.status(200).json({
		success: true,
		message: "Tools reordered successfully",
	});
});

export { addTool, deleteTool, getTools, reorderTools, updateTool };
