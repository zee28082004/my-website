import { RequestHandler } from "express";
import { ImageDeleteUtil } from "../../helpers/cloudinary";
import { invalidateCache } from "../../middlewares/cache.middleware";
import Project from "../../models/project";
import { AppError } from "../../utils/AppError";
import asyncHandler from "../../utils/asyncHandler";

const CACHE_TAG = "projects";

const addProject: RequestHandler = asyncHandler(async (req, res) => {
	await Project.create(req.body);
	invalidateCache(CACHE_TAG);
	res.status(201).json({
		success: true,
		message: "Project created successfully",
	});
});

const getProjects: RequestHandler = asyncHandler(async (_req, res) => {
	const projects = await Project.find()
		.sort({ order: 1, createdAt: -1 })
		.select("-image.public_id -__v")
		.lean();

	res.status(200).json({
		success: true,
		message: "Projects fetched",
		projects,
	});
});

const updateProject: RequestHandler = asyncHandler(async (req, res) => {
	const { id } = req.params;
	const data = req.body;

	const project = await Project.findById(id);
	if (!project) throw new AppError("Project not found", 404);

	if (data.image?.url && data.image?.public_id && project.image?.public_id) {
		await ImageDeleteUtil(project.image.public_id);
	}

	Object.assign(project, {
		image: data.image ?? project.image,
		title: data.title ?? project.title,
		description: data.description ?? project.description,
		tools: data.tools ?? project.tools,
		github_link: data.github_link ?? project.github_link,
		live_link: data.live_link ?? project.live_link,
	});

	await project.save();
	invalidateCache(CACHE_TAG);

	res.status(200).json({
		success: true,
		message: "Project updated successfully",
	});
});

const deleteProject: RequestHandler = asyncHandler(async (req, res) => {
	const { id } = req.params;

	const project = await Project.findById(id);
	if (!project) throw new AppError("Project not found", 404);

	if (project.image?.public_id) {
		await ImageDeleteUtil(project.image.public_id);
	}
	await Project.deleteOne({ _id: id });
	invalidateCache(CACHE_TAG);

	res.status(200).json({
		success: true,
		message: "Project deleted successfully",
	});
});

const reorderProjects: RequestHandler = asyncHandler(async (req, res) => {
	const { projects } = req.body;

	const operations = projects.map((id: string, index: number) => ({
		updateOne: {
			filter: { _id: id },
			update: { $set: { order: index } },
		},
	}));

	if (operations.length) await Project.bulkWrite(operations);
	invalidateCache(CACHE_TAG);

	res.status(200).json({
		success: true,
		message: "Projects reordered successfully",
	});
});

export {
	addProject,
	deleteProject,
	getProjects,
	reorderProjects,
	updateProject,
};
