import bcrypt from "bcryptjs";
import { RequestHandler } from "express";
import jwt from "jsonwebtoken";
import {
	access_tokenOptions,
	generate_access_token,
} from "../../helpers/jwtGenerate";
import { invalidateAuthCache } from "../../middlewares/auth.middleware";
import Admin from "../../models/admin";
import { AppError } from "../../utils/AppError";
import asyncHandler from "../../utils/asyncHandler";
import env from "../../utils/env";

const loginUser: RequestHandler = asyncHandler(async (req, res) => {
	const { email, password } = req.body as { email: string; password: string };

	const admin = await Admin.findOne({ email }).select("+password");
	if (!admin) throw new AppError("Invalid email or password", 401);

	const isPasswordCorrect = await bcrypt.compare(password, admin.password);
	if (!isPasswordCorrect) throw new AppError("Invalid email or password", 401);

	const user = {
		id: admin._id.toString(),
		email: admin.email,
		username: admin.username,
	};

	const access_token = generate_access_token(user);

	res.status(200)
		.cookie("_access_token", access_token, access_tokenOptions)
		.json({
			success: true,
			user,
			message: "Login successful",
		});
});

/**
 * Logout is intentionally public so users with an expired or invalid token
 * can still clear their cookie. We try to bust the auth cache by decoding
 * the token (without verifying expiry); failure is non-fatal.
 */
const logoutUser: RequestHandler = asyncHandler(async (req, res) => {
	const token = req.cookies?._access_token;
	if (token) {
		try {
			const decoded = jwt.verify(token, env.TOKEN_KEY, {
				algorithms: ["HS256"],
				ignoreExpiration: true,
			}) as { user?: { id?: string } };
			if (decoded?.user?.id) invalidateAuthCache(decoded.user.id);
		} catch {
			// best-effort; ignore signature/format errors
		}
	}

	res.clearCookie("_access_token", {
		httpOnly: true,
		secure: env.isProd,
		sameSite: env.isProd ? "none" : "lax",
		path: "/",
	});

	res.status(200).json({ success: true, message: "User logged out" });
});

export { loginUser, logoutUser };
