import compression from "compression";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { Express, RequestHandler } from "express";
import helmet from "helmet";
import mongoose from "mongoose";
import { corsOptions } from "./config/cors";
import { limiter } from "./helpers/rateLimit";
import errorHandler from "./middlewares/error.middleware";
import { httpLogger } from "./middlewares/httpLogger.middleware";
import { notFound } from "./middlewares/notFound";
import { requestId } from "./middlewares/requestId.middleware";
import { sanitizeBody } from "./middlewares/sanitize.middleware";
import emailRoute from "./routes/admin/email.route";
import imageRoute from "./routes/admin/image.route";
import projectRoute from "./routes/admin/project.route";
import toolRoute from "./routes/admin/tool.route";
import authRoute from "./routes/auth/auth.route";
import env from "./utils/env";

type CreateAppOptions = {
	/**
	 * Optional middleware run after health checks but before routes.
	 * Used by the Vercel entry to lazily connect to Mongo on first request.
	 */
	ensureReady?: RequestHandler;
};

export const createApp = (options: CreateAppOptions = {}): Express => {
	const app = express();

	app.disable("x-powered-by");
	if (env.TRUST_PROXY) app.set("trust proxy", 1);

	// Health endpoints — never blocked by middleware, never trigger DB connect.
	app.get("/healthz", (_req, res) => {
		res.status(200).json({ status: "ok", uptime: process.uptime() });
	});
	app.get("/readyz", (_req, res) => {
		const dbReady = mongoose.connection.readyState === 1;
		res.status(dbReady ? 200 : 503).json({
			status: dbReady ? "ready" : "not_ready",
			db: dbReady,
		});
	});

	app.use(requestId);
	app.use(httpLogger);
	app.use(helmet());
	app.use(cors(corsOptions));
	app.use(cookieParser());
	app.use(express.json({ limit: "1mb" }));
	app.use(express.urlencoded({ extended: true, limit: "1mb" }));
	app.use(sanitizeBody);
	app.use(compression());
	app.use(limiter);

	if (options.ensureReady) app.use(options.ensureReady);

	app.get("/", (_req, res) => {
		res.status(200).json({ message: "Server is up & running" });
	});

	app.use("/api/auth", authRoute);
	app.use("/api/admin/tool", toolRoute);
	app.use("/api/admin/image", imageRoute);
	app.use("/api/admin/project", projectRoute);
	app.use("/api/admin/email", emailRoute);

	app.use(notFound);
	app.use(errorHandler);

	return app;
};
