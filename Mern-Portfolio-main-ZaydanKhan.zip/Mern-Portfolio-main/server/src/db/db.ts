import mongoose from "mongoose";
import logger from "../config/logger";
import env from "../utils/env";

mongoose.set("strictQuery", true);

type CachedConnection = {
	conn: typeof mongoose | null;
	promise: Promise<typeof mongoose> | null;
};

// Global cache survives warm Vercel invocations (serverless best practice)
const globalCache = globalThis as typeof globalThis & {
	__mongooseCache?: CachedConnection;
};

const cache: CachedConnection =
	globalCache.__mongooseCache ?? { conn: null, promise: null };
globalCache.__mongooseCache = cache;

const MAX_RETRIES = 5;
const RETRY_DELAY_MS = 2_000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const connectWithRetry = async (): Promise<typeof mongoose> => {
	for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
		try {
			const conn = await mongoose.connect(env.MONGO_URI, {
				connectTimeoutMS: 10_000,
				socketTimeoutMS: 45_000,
				serverSelectionTimeoutMS: 10_000,
				maxPoolSize: 10,
				minPoolSize: 0,
				retryWrites: true,
			});
			logger.info(
				{ attempt, host: conn.connection.host },
				"MongoDB connected",
			);
			return conn;
		} catch (error) {
			const message = error instanceof Error ? error.message : "unknown";
			logger.error(
				{ attempt, max: MAX_RETRIES, error: message },
				"MongoDB connection failed",
			);
			if (attempt === MAX_RETRIES) throw error;
			await sleep(RETRY_DELAY_MS * attempt);
		}
	}
	throw new Error("Unreachable");
};

const connectToDB = async (): Promise<typeof mongoose> => {
	if (cache.conn) return cache.conn;
	if (!cache.promise) {
		cache.promise = connectWithRetry().catch((err) => {
			cache.promise = null; // allow retry on next call
			throw err;
		});
	}
	cache.conn = await cache.promise;
	return cache.conn;
};

mongoose.connection.on("disconnected", () => {
	logger.warn("MongoDB disconnected");
	cache.conn = null;
	cache.promise = null;
});

mongoose.connection.on("reconnected", () => logger.info("MongoDB reconnected"));
mongoose.connection.on("error", (error) =>
	logger.error({ error: error.message }, "MongoDB error"),
);

export default connectToDB;
