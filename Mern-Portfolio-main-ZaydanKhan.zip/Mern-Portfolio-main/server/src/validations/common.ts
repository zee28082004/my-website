import mongoose from "mongoose";
import zod from "zod";

export const objectId = zod
	.string()
	.refine((v) => mongoose.Types.ObjectId.isValid(v), {
		message: "Invalid ID format",
	});

export const idParamSchema = zod.object({ id: objectId });

export type IdParam = zod.infer<typeof idParamSchema>;
