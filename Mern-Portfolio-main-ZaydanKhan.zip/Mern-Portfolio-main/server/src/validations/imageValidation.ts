import zod from "zod";

export const deleteImageSchema = zod.object({
	id: zod.string().min(1, "Image id is required"),
});
