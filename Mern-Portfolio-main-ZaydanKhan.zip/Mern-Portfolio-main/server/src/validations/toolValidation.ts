import zod from "zod";
import { objectId } from "./common";

const toolSchema = zod.object({
	name: zod.string().min(1, "Name is required"),
	image: zod.object({
		url: zod.url(),
		public_id: zod.string(),
	}),
});

const updateToolSchema = toolSchema.partial().extend({
	image: toolSchema.shape.image.optional(),
});

const reorderToolsSchema = zod.object({
	tools: zod.array(objectId).nonempty("Tool list is required"),
});

export { reorderToolsSchema, toolSchema, updateToolSchema };
