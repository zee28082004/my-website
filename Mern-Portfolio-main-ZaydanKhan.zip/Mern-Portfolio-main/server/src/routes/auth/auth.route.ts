import express, { Request, Response, Router } from "express";
import { loginUser, logoutUser } from "../../controllers/auth/auth.controller";
import { loginLimiter } from "../../helpers/rateLimit";
import authMiddleware from "../../middlewares/auth.middleware";
import { validate } from "../../middlewares/validate.middleware";
import { loginSchema } from "../../validations/authValidation";

const router: Router = express.Router();

router.post("/login", loginLimiter, validate(loginSchema), loginUser);
router.post("/logout", logoutUser);
router.get("/check-auth", authMiddleware, (req: Request, res: Response) => {
	res.status(200).json({
		success: true,
		message: "Authenticated user",
		user: req.user,
	});
});

export default router;
