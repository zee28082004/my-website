import express, { Router } from "express";
import {
	addProject,
	deleteProject,
	getProjects,
	reorderProjects,
	updateProject,
} from "../../controllers/admin/project.controller";
import authMiddleware from "../../middlewares/auth.middleware";
import { cacheGet } from "../../middlewares/cache.middleware";
import { validate } from "../../middlewares/validate.middleware";
import { idParamSchema } from "../../validations/common";
import {
	projectSchema,
	reorderProjectsSchema,
	updateProjectSchema,
} from "../../validations/projectValidation";

const router: Router = express.Router();

router.get("/get-projects", cacheGet("projects", 60_000), getProjects);

router.post(
	"/add-project",
	authMiddleware,
	validate(projectSchema),
	addProject,
);

router.put(
	"/update-project/:id",
	authMiddleware,
	validate(idParamSchema, "params"),
	validate(updateProjectSchema),
	updateProject,
);

router.post(
	"/reorder-projects",
	authMiddleware,
	validate(reorderProjectsSchema),
	reorderProjects,
);

router.delete(
	"/delete-project/:id",
	authMiddleware,
	validate(idParamSchema, "params"),
	deleteProject,
);

export default router;
