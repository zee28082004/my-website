import express, { Router } from "express";
import { sendEmail } from "../../controllers/admin/email.controller";
import { mailLimiter } from "../../helpers/rateLimit";
import { validate } from "../../middlewares/validate.middleware";
import emailSchema from "../../validations/emailValidation";

const router: Router = express.Router();

router.post("/send-email", mailLimiter, validate(emailSchema), sendEmail);

export default router;
