import express, { Router } from "express";
import {
	addTool,
	deleteTool,
	getTools,
	reorderTools,
	updateTool,
} from "../../controllers/admin/tool.controller";
import authMiddleware from "../../middlewares/auth.middleware";
import { cacheGet } from "../../middlewares/cache.middleware";
import { validate } from "../../middlewares/validate.middleware";
import { idParamSchema } from "../../validations/common";
import {
	reorderToolsSchema,
	toolSchema,
	updateToolSchema,
} from "../../validations/toolValidation";

const router: Router = express.Router();

router.get("/get-tools", cacheGet("tools", 60_000), getTools);

router.post("/add-tool", authMiddleware, validate(toolSchema), addTool);

router.put(
	"/update-tool/:id",
	authMiddleware,
	validate(idParamSchema, "params"),
	validate(updateToolSchema),
	updateTool,
);

router.post(
	"/reorder-tools",
	authMiddleware,
	validate(reorderToolsSchema),
	reorderTools,
);

// Admin client uses POST for delete-tool — keep contract.
router.post(
	"/delete-tool/:id",
	authMiddleware,
	validate(idParamSchema, "params"),
	deleteTool,
);

export default router;
