import { v2 as cloudinary } from "cloudinary";
import multer, { FileFilterCallback } from "multer";
import type { Request } from "express";
import { AppError } from "../utils/AppError";
import env from "../utils/env";

cloudinary.config({
	cloud_name: env.CLOUDINARY_CLOUD_NAME,
	api_key: env.CLOUDINARY_API_KEY,
	api_secret: env.CLOUDINARY_API_SECRET,
	secure: true,
});

const ALLOWED_MIME = new Set([
	"image/jpeg",
	"image/png",
	"image/webp",
	"image/gif",
	"image/avif",
]);
const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5MB

const fileFilter = (
	_req: Request,
	file: Express.Multer.File,
	cb: FileFilterCallback,
) => {
	if (!ALLOWED_MIME.has(file.mimetype)) {
		return cb(new AppError("Unsupported image type", 415));
	}
	cb(null, true);
};

const upload = multer({
	storage: multer.memoryStorage(),
	limits: { fileSize: MAX_FILE_BYTES, files: 1 },
	fileFilter,
});

const ImageUploadUtil = async (image: string) => {
	const result = await cloudinary.uploader.upload(image, {
		resource_type: "image",
		eager: [{ format: "webp", quality: "auto" }],
		eager_async: false,
	});
	return {
		url: result.eager?.[0]?.secure_url,
		public_id: result.public_id,
	};
};

const ImageDeleteUtil = async (imgId: string) =>
	cloudinary.uploader.destroy(imgId);

export { ImageDeleteUtil, ImageUploadUtil, upload };
