import { CookieOptions } from "express";
import jwt from "jsonwebtoken";
import ms from "ms";
import env from "../utils/env";

interface UserPayload {
	id: string;
	email: string;
	username: string;
}

export const generate_access_token = (user: UserPayload): string => {
	const expiresIn = env.TOKEN_KEY_EXPIRY as ms.StringValue;
	return jwt.sign({ user }, env.TOKEN_KEY, {
		expiresIn,
		algorithm: "HS256",
	});
};

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export const access_tokenOptions: CookieOptions = {
	httpOnly: true,
	secure: env.isProd,
	sameSite: env.isProd ? "none" : "lax",
	path: "/",
	maxAge: SEVEN_DAYS_MS,
};
