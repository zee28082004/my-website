import "dotenv/config";
import { NextFunction, Request, Response } from "express";
import { createApp } from "./app.factory";
import logger from "./config/logger";
import connectToDB from "./db/db";

/**
 * Vercel-friendly entry point.
 * - Default-exports an Express app (Vercel's @vercel/node treats it as a handler)
 * - Connects to Mongo lazily on the first request (warm invocations reuse via global cache in db/db.ts)
 * - Health endpoints (/healthz, /readyz) are mounted in the factory before this middleware,
 *   so probes never trigger a DB connect.
 *
 * For local / non-serverless deployments, use `server.ts` (it eagerly connects + listens).
 */
const ensureReady = async (
	_req: Request,
	_res: Response,
	next: NextFunction,
) => {
	try {
		await connectToDB();
		next();
	} catch (error) {
		logger.error({ err: error }, "Lazy DB connect failed");
		next(error);
	}
};

const app = createApp({ ensureReady });

export default app;
