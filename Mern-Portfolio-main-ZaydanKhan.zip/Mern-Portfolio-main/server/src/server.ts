import "dotenv/config";
import http from "node:http";
import mongoose from "mongoose";
import { createApp } from "./app.factory";
import logger from "./config/logger";
import connectToDB from "./db/db";
import env from "./utils/env";

const SHUTDOWN_TIMEOUT_MS = 15_000;

const start = async () => {
	try {
		await connectToDB();
	} catch (error) {
		logger.fatal({ err: error }, "Failed to connect to DB on boot");
		process.exit(1);
	}

	const app = createApp();
	const server = http.createServer(app);

	server.keepAliveTimeout = 65_000;
	server.headersTimeout = 66_000;

	server.listen(env.PORT, () => {
		logger.info({ port: env.PORT, env: env.NODE_ENV }, "Server listening");
	});

	const shutdown = async (signal: string) => {
		logger.warn({ signal }, "Shutdown initiated");

		const forceTimer = setTimeout(() => {
			logger.error("Force exit after shutdown timeout");
			process.exit(1);
		}, SHUTDOWN_TIMEOUT_MS);
		forceTimer.unref();

		try {
			await new Promise<void>((resolve, reject) => {
				server.close((err) => (err ? reject(err) : resolve()));
			});
			logger.info("HTTP server closed");

			await mongoose.disconnect();
			logger.info("MongoDB disconnected");

			clearTimeout(forceTimer);
			process.exit(0);
		} catch (error) {
			logger.error({ err: error }, "Error during shutdown");
			process.exit(1);
		}
	};

	process.on("SIGINT", () => void shutdown("SIGINT"));
	process.on("SIGTERM", () => void shutdown("SIGTERM"));

	process.on("unhandledRejection", (reason) => {
		logger.error({ err: reason }, "Unhandled promise rejection");
	});

	process.on("uncaughtException", (err) => {
		logger.fatal({ err }, "Uncaught exception — exiting");
		void shutdown("uncaughtException");
	});
};

void start();
