import { bool, cleanEnv, email, num, str, url } from "envalid";

const env = cleanEnv(process.env, {
	NODE_ENV: str({ choices: ["development", "production", "test"] }),
	PORT: num(),
	LOG_LEVEL: str({
		choices: ["fatal", "error", "warn", "info", "debug", "trace", "silent"],
		default: "info",
	}),

	MONGO_URI: url(),

	CLOUDINARY_CLOUD_NAME: str(),
	CLOUDINARY_API_KEY: str(),
	CLOUDINARY_API_SECRET: str(),

	GMAIL_USER: email(),
	GMAIL_PASSWORD: str(),
	GMAIL_ID: email(),

	TOKEN_KEY: str(),
	TOKEN_KEY_EXPIRY: str(),

	ADMIN_URL: url(),
	CLIENT_URL: url(),
	PROD_URL: url(),
	PROD_S_URL: url(),

	TRUST_PROXY: bool({ default: true }),
});

export default env;
