type Entry<T> = {
	value: T;
	expiresAt: number;
	tags: Set<string>;
};

export class TTLCache<T> {
	private store = new Map<string, Entry<T>>();
	private tagIndex = new Map<string, Set<string>>();

	constructor(private maxSize = 500) {}

	get(key: string): T | undefined {
		const entry = this.store.get(key);
		if (!entry) return undefined;
		if (entry.expiresAt < Date.now()) {
			this.delete(key);
			return undefined;
		}
		return entry.value;
	}

	set(key: string, value: T, ttlMs: number, tags: string[] = []): void {
		if (this.store.size >= this.maxSize) this.evictOldest();

		const tagSet = new Set(tags);
		this.store.set(key, {
			value,
			expiresAt: Date.now() + ttlMs,
			tags: tagSet,
		});

		for (const tag of tagSet) {
			let bucket = this.tagIndex.get(tag);
			if (!bucket) {
				bucket = new Set();
				this.tagIndex.set(tag, bucket);
			}
			bucket.add(key);
		}
	}

	delete(key: string): void {
		const entry = this.store.get(key);
		if (!entry) return;
		this.store.delete(key);
		for (const tag of entry.tags) this.tagIndex.get(tag)?.delete(key);
	}

	invalidateTag(tag: string): void {
		const bucket = this.tagIndex.get(tag);
		if (!bucket) return;
		for (const key of bucket) this.store.delete(key);
		this.tagIndex.delete(tag);
	}

	clear(): void {
		this.store.clear();
		this.tagIndex.clear();
	}

	private evictOldest(): void {
		const oldest = this.store.keys().next().value;
		if (oldest) this.delete(oldest);
	}
}
