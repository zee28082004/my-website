import mongoose, { Model, Schema } from "mongoose";
import { IProject } from "../types/types";

const ProjectSchema = new Schema<IProject>(
	{
		title: { type: String, required: true, trim: true, index: true },
		image: {
			url: { type: String, required: true },
			public_id: { type: String, required: true },
		},
		description: { type: String, required: true, trim: true },
		github_link: { type: String, trim: true },
		live_link: { type: String, trim: true },
		tools: {
			type: [
				{
					id: { type: String },
					text: { type: String, required: true, trim: true },
				},
			],
			required: true,
		},
		order: { type: Number, default: 0, index: true },
	},
	{ timestamps: true },
);

ProjectSchema.index({ order: 1, createdAt: -1 });

const Project: Model<IProject> =
	mongoose.models.Project ||
	mongoose.model<IProject>("Project", ProjectSchema);

export default Project;
