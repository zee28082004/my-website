import { pinoHttp } from "pino-http";
import logger from "../config/logger";

export const httpLogger = pinoHttp({
	logger,
	genReqId: (req) => (req as { id?: string }).id ?? "",
	customLogLevel: (_req, res, err) => {
		if (err || res.statusCode >= 500) return "error";
		if (res.statusCode >= 400) return "warn";
		if (res.statusCode >= 300) return "silent";
		return "info";
	},
	customSuccessMessage: (req, res) =>
		`${req.method} ${req.url} ${res.statusCode}`,
	customErrorMessage: (req, res, err) =>
		`${req.method} ${req.url} ${res.statusCode} ${err.message}`,
	customProps: (req) => ({ requestId: (req as { id?: string }).id }),
	autoLogging: {
		ignore: (req) => req.url === "/healthz" || req.url === "/readyz",
	},
});
