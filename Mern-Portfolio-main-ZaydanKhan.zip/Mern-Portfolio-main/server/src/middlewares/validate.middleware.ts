import { NextFunction, Request, RequestHandler, Response } from "express";
import { ZodType, z } from "zod";
import { AppError } from "../utils/AppError";

type Source = "body" | "query" | "params";

export const validate =
	<T extends ZodType>(schema: T, source: Source = "body"): RequestHandler =>
	(req: Request, _res: Response, next: NextFunction) => {
		const input = source === "body" ? req.body : req[source];
		const result = schema.safeParse(input);

		if (!result.success) {
			return next(
				new AppError("Validation failed", 422, z.flattenError(result.error)),
			);
		}

		// Attach the parsed (and typed) value back to the request for the controller.
		// We don't reassign req.query/req.params (Express 5 makes them read-only).
		if (source === "body") req.body = result.data;
		else (req as Request & Record<Source, unknown>).validated = result.data;

		next();
	};

declare global {
	// eslint-disable-next-line @typescript-eslint/no-namespace
	namespace Express {
		interface Request {
			validated?: unknown;
		}
	}
}
