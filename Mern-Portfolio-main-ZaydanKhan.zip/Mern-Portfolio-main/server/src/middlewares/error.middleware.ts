import { ErrorRequestHandler } from "express";
import {
	JsonWebTokenError,
	NotBeforeError,
	TokenExpiredError,
} from "jsonwebtoken";
import multer from "multer";
import mongoose from "mongoose";
import { ZodError, z } from "zod";
import logger from "../config/logger";
import { AppError } from "../utils/AppError";
import env from "../utils/env";

type NormalizedError = {
	statusCode: number;
	message: string;
	details?: unknown;
};

const normalize = (err: unknown): NormalizedError => {
	if (err instanceof AppError) {
		return {
			statusCode: err.statusCode,
			message: err.message,
			details: err.details,
		};
	}

	if (err instanceof ZodError) {
		return {
			statusCode: 422,
			message: "Validation failed",
			details: z.flattenError(err),
		};
	}

	if (err instanceof mongoose.Error.ValidationError) {
		return {
			statusCode: 422,
			message: "Validation failed",
			details: Object.fromEntries(
				Object.entries(err.errors).map(([key, value]) => [key, value.message]),
			),
		};
	}

	if (err instanceof mongoose.Error.CastError) {
		return {
			statusCode: 400,
			message: `Invalid value for "${err.path}"`,
		};
	}

	// Mongo duplicate key
	if (
		err instanceof mongoose.mongo.MongoServerError &&
		err.code === 11000
	) {
		return {
			statusCode: 409,
			message: "Duplicate resource",
			details: err.keyValue,
		};
	}

	if (
		err instanceof TokenExpiredError ||
		err instanceof JsonWebTokenError ||
		err instanceof NotBeforeError
	) {
		return { statusCode: 401, message: "Invalid or expired token" };
	}

	if (err instanceof multer.MulterError) {
		const map: Record<string, [number, string]> = {
			LIMIT_FILE_SIZE: [413, "File too large"],
			LIMIT_FILE_COUNT: [400, "Too many files"],
			LIMIT_UNEXPECTED_FILE: [400, "Unexpected file field"],
		};
		const [code, msg] = map[err.code] ?? [400, "Upload error"];
		return { statusCode: code, message: msg };
	}

	return { statusCode: 500, message: "Internal Server Error" };
};

const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
	const { statusCode, message, details } = normalize(err);
	const stack = err instanceof Error ? err.stack : undefined;

	const log = req.log ?? logger;
	const payload = {
		requestId: req.id,
		statusCode,
		path: req.originalUrl,
		method: req.method,
		err: { message, stack },
	};

	if (statusCode >= 500) log.error(payload, "Unhandled error");
	else log.warn(payload, "Request error");

	res.status(statusCode).json({
		success: false,
		message,
		...(details !== undefined ? { errors: details } : {}),
		...(env.isDev && stack ? { stack } : {}),
		requestId: req.id,
	});
};

export default errorHandler;
