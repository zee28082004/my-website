import { NextFunction, Request, Response } from "express";

const FORBIDDEN = /^\$|\./;

const cleanObject = (value: unknown): void => {
	if (!value || typeof value !== "object") return;

	if (Array.isArray(value)) {
		value.forEach(cleanObject);
		return;
	}

	for (const key of Object.keys(value)) {
		if (FORBIDDEN.test(key)) {
			delete (value as Record<string, unknown>)[key];
			continue;
		}
		cleanObject((value as Record<string, unknown>)[key]);
	}
};

/**
 * Express 5 makes req.query / req.params read-only, so we only sanitize
 * req.body. NoSQL injection via query/params is mitigated by Zod validation
 * applied at the route level (validate middleware).
 */
export const sanitizeBody = (
	req: Request,
	_res: Response,
	next: NextFunction,
) => {
	if (req.body && typeof req.body === "object") cleanObject(req.body);
	next();
};
