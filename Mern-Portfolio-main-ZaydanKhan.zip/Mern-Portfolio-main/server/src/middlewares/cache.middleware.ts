import { createHash } from "node:crypto";
import { NextFunction, Request, RequestHandler, Response } from "express";
import { TTLCache } from "../utils/ttlCache";

type CachedPayload = {
	body: unknown;
	etag: string;
};

const httpCache = new TTLCache<CachedPayload>(500);

const computeETag = (body: unknown): string =>
	`"${createHash("sha1").update(JSON.stringify(body)).digest("hex")}"`;

export const invalidateCache = (tag: string): void => {
	httpCache.invalidateTag(tag);
};

export const cacheGet = (
	tag: string,
	ttlMs = 60_000,
): RequestHandler =>
	(req: Request, res: Response, next: NextFunction) => {
		if (req.method !== "GET") return next();

		const key = `${tag}:${req.originalUrl}`;
		const cached = httpCache.get(key);
		const maxAge = Math.floor(ttlMs / 1000);

		if (cached) {
			res.setHeader("ETag", cached.etag);
			res.setHeader("Cache-Control", `public, max-age=${maxAge}`);
			res.setHeader("X-Cache", "HIT");

			if (req.headers["if-none-match"] === cached.etag) {
				res.status(304).end();
				return;
			}
			res.status(200).json(cached.body);
			return;
		}

		const originalJson = res.json.bind(res);
		res.json = (body: unknown) => {
			if (res.statusCode >= 200 && res.statusCode < 300) {
				const etag = computeETag(body);
				httpCache.set(key, { body, etag }, ttlMs, [tag]);
				res.setHeader("ETag", etag);
				res.setHeader("Cache-Control", `public, max-age=${maxAge}`);
				res.setHeader("X-Cache", "MISS");
			}
			return originalJson(body);
		};
		next();
	};
