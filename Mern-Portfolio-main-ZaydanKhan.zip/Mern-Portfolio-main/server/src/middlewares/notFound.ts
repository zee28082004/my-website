import { NextFunction, Request, Response } from "express";
import { AppError } from "../utils/AppError";

const notFound = (req: Request, _res: Response, next: NextFunction) => {
	next(new AppError(`Route ${req.method} ${req.originalUrl} not found`, 404));
};

export { notFound };
