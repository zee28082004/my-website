import { randomUUID } from "node:crypto";
import { NextFunction, Request, Response } from "express";

const HEADER = "x-request-id";

export const requestId = (req: Request, res: Response, next: NextFunction) => {
	const incoming = req.header(HEADER);
	const id = incoming && incoming.length <= 128 ? incoming : randomUUID();
	req.id = id;
	res.setHeader(HEADER, id);
	next();
};

declare global {
	// eslint-disable-next-line @typescript-eslint/no-namespace
	namespace Express {
		interface Request {
			id: string;
		}
	}
}
