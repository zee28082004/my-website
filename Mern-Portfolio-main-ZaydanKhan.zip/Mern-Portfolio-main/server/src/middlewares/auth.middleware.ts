import { NextFunction, Request, Response } from "express";
import jwt, { JwtPayload } from "jsonwebtoken";
import Admin from "../models/admin";
import { AppError } from "../utils/AppError";
import asyncHandler from "../utils/asyncHandler";
import { TTLCache } from "../utils/ttlCache";
import env from "../utils/env";

export interface AuthUser {
	id: string;
	email: string;
	username: string;
}

interface TokenPayload extends JwtPayload {
	user?: AuthUser;
}

const ADMIN_TTL_MS = 60_000; // 60s
const adminCache = new TTLCache<AuthUser>(200);

export const invalidateAuthCache = (adminId: string) => {
	adminCache.delete(adminId);
};

const resolveAdmin = async (id: string): Promise<AuthUser | null> => {
	const cached = adminCache.get(id);
	if (cached) return cached;

	const admin = await Admin.findById(id).select("_id email username").lean();
	if (!admin) return null;

	const user: AuthUser = {
		id: admin._id.toString(),
		email: admin.email,
		username: admin.username,
	};
	adminCache.set(id, user, ADMIN_TTL_MS);
	return user;
};

const authMiddleware = asyncHandler(
	async (req: Request, _res: Response, next: NextFunction) => {
		const token = req.cookies?._access_token;

		if (!token) {
			throw new AppError("Unauthenticated: No token provided", 401);
		}

		let decoded: TokenPayload;
		try {
			decoded = jwt.verify(token, env.TOKEN_KEY, {
				algorithms: ["HS256"],
			}) as TokenPayload;
		} catch {
			throw new AppError("Unauthenticated: Invalid or expired token", 401);
		}

		const adminId = decoded?.user?.id;
		if (!adminId) {
			throw new AppError("Unauthenticated: Invalid token payload", 401);
		}

		const user = await resolveAdmin(adminId);
		if (!user) {
			throw new AppError("Unauthenticated: Admin not found", 401);
		}

		req.user = user;
		next();
	},
);

declare global {
	// eslint-disable-next-line @typescript-eslint/no-namespace
	namespace Express {
		interface Request {
			user?: AuthUser;
		}
	}
}

export default authMiddleware;
