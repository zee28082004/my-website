import pino from "pino";
import env from "../utils/env";

const logger = pino({
	level: env.LOG_LEVEL,
	base: { env: env.NODE_ENV },
	timestamp: pino.stdTimeFunctions.isoTime,
	redact: {
		paths: [
			"req.headers.authorization",
			"req.headers.cookie",
			"req.headers['x-api-key']",
			"res.headers['set-cookie']",
			'*.password',
			'*.token',
			'*.access_token',
			'*._access_token',
		],
		censor: "[REDACTED]",
	},
	transport: env.isDev
		? {
				target: "pino-pretty",
				options: {
					colorize: true,
					translateTime: "SYS:HH:MM:ss.l",
					ignore: "pid,hostname,env",
				},
			}
		: undefined,
});

export default logger;
