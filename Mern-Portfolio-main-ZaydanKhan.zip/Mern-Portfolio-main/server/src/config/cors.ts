import type { CorsOptions } from "cors";
import logger from "./logger";
import env from "../utils/env";

const allowedOrigins = new Set(
	[env.CLIENT_URL, env.ADMIN_URL, env.PROD_URL, env.PROD_S_URL].filter(
		Boolean,
	),
);

export const corsOptions: CorsOptions = {
	origin: (origin, callback) => {
		// Allow same-origin / server-to-server (no Origin header)
		if (!origin) return callback(null, true);

		if (allowedOrigins.has(origin)) return callback(null, true);

		logger.warn({ origin }, "CORS blocked request");
		callback(new Error(`Origin ${origin} not allowed by CORS`));
	},
	methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
	credentials: true,
	maxAge: 86_400,
};
